from django.shortcuts import render, redirect
from .models import Task

def task_list(request):
    if request.method == 'POST':
        # POST: Add new task
        title = request.POST.get('title')
        if title:
            Task.objects.create(title=title)
        return redirect('task_list')

    else:
        # GET: Show tasks
        tasks = Task.objects.all()
        return render(request, 'todo_app/task_list.html', {'tasks': tasks})
from django.shortcuts import get_object_or_404

def complete_task(request, task_id):
    if request.method == 'POST':
        task = get_object_or_404(Task, id=task_id)
        task.completed = True
        task.save()
    return redirect('task_list')

def delete_task(request, task_id):
    if request.method == 'POST':
        task = get_object_or_404(Task, id=task_id)
        task.delete()
    return redirect('task_list')

